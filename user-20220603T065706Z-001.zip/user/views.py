from django.shortcuts import render,redirect

from . import models

import time

#middleware to check session for user routes
def sessioncheckuser_middleware(get_response):
	def middleware(request):
		if request.path=='/user/':
			if request.session['sunm']==None or request.session['srole']!="user":
				response = redirect('/login/')
			else:
				response = get_response(request)
		else:
			response = get_response(request)		
		return response	
	return middleware

# Create your views here.
def userhome(request):
 return render(request,"userhome.html",{"sunm":request.session["sunm"]})

def funds(request):
 paypalURL="https://www.sandbox.paypal.com/cgi-bin/webscr"
 paypalID="sb-jaqa815242589@business.example.com"
 #sb-oqg0d16659741@personal.example.com
 price=100
 return render(request,"funds.html",{"price":price,"paypalID":paypalID,"paypalURL":paypalURL,"sunm":request.session["sunm"]})

def payment(request):
 #amt=100&uid=adawadkarvilekh@gmail.com&PayerID=4ZGU2N24JMJHG 	
 amt=request.GET.get("amt")
 uid=request.GET.get("uid")
 txnid=request.GET.get("PayerID")
 info=time.asctime()
 p=models.Payment(txnid=txnid,userid=uid,amount=amt,info=info)
 p.save()
 return redirect("/user/success/")

def success(request):
 return render(request,"success.html",{"sunm":request.session["sunm"]})

def cancel(request):
 return render(request,"cancel.html",{"sunm":request.session["sunm"]}) 