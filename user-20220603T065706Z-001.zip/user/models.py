from django.db import models

# Create your models here.

class Payment(models.Model):
    paymentid=models.AutoField(primary_key=True)
    txnid=models.CharField(max_length=50)
    userid=models.CharField(max_length=50)
    amount=models.CharField(max_length=10)
    info=models.CharField(max_length=50)