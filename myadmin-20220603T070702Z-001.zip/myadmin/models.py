from django.db import models

class Category(models.Model):
    catid=models.AutoField(primary_key=True)
    catnm=models.CharField(max_length=50,unique=True)
    caticonnm=models.CharField(max_length=100)

class SubCategory(models.Model):
    subcatid=models.AutoField(primary_key=True)
    catnm=models.CharField(max_length=50)
    subcatnm=models.CharField(max_length=50,unique=True)
    subcaticonnm=models.CharField(max_length=100)

class Product(models.Model):
    pid=models.AutoField(primary_key=True)
    ptitle=models.CharField(max_length=50)
    pcategory=models.CharField(max_length=50)
    pscategory=models.CharField(max_length=50)
    pdescription=models.CharField(max_length=500)
    pprice=models.CharField(max_length=10)    

