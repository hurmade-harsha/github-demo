from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage

from mydjapp import models as mydjapp_models
from user import models as user_models
import user
from . import models
import mydjapp

# Create your views here.

#middleware to check session for admin routes
def sessioncheckmyadmin_middleware(get_response):
	def middleware(request):
		if request.path=='/myadmin/' or request.path=='/myadmin/addcategory/' or request.path=='/myadmin/addsubcategory/' or request.path=='/myadmin/manageusers/' or request.path=='/myadmin/manageuserstatus/':
			if request.session['sunm']==None or request.session['srole']!="admin":
				response = redirect('/login/')
			else:
				response = get_response(request)
		else:
			response = get_response(request)		
		return response	
	return middleware

def adminhome(request):
 return render(request,"adminhome.html",{"sunm":request.session["sunm"]})

def manageusers(request):
 userDetails=mydjapp_models.Register.objects.filter(role='user')
 return render(request,"manageusers.html",{'userDetails':userDetails,"sunm":request.session["sunm"]})

def manageuserstatus(request):
 regid=request.GET.get("regid")
 s=request.GET.get("s")
 if s=="block":
  mydjapp_models.Register.objects.filter(regid=int(regid)).update(status=0)
 elif s=="verify":
  mydjapp_models.Register.objects.filter(regid=int(regid)).update(status=1)             
 else:
  mydjapp_models.Register.objects.filter(regid=int(regid)).delete()    
 return redirect("/myadmin/manageusers/")

def addcategory(request):
 if request.method=="GET":    
  return render(request,"addcategory.html",{"output":"","sunm":request.session["sunm"]})
 else:
  catnm=request.POST.get("catnm")
  caticon=request.FILES["caticon"]
  fs = FileSystemStorage()
  filename = fs.save(caticon.name,caticon)
  p=models.Category(catnm=catnm,caticonnm=filename)  
  p.save()      
  return render(request,"addcategory.html",{"output":"Category added successfully....","sunm":request.session["sunm"]})

def addsubcategory(request):
 clist=models.Category.objects.all()        
 if request.method=="GET":    
  return render(request,"addsubcategory.html",{"output":"","clist":clist,"sunm":request.session["sunm"]})
 else:
  catnm=request.POST.get("catnm")
  subcatnm=request.POST.get("subcatnm")
  caticon=request.FILES["caticon"]
  fs = FileSystemStorage()
  filename = fs.save(caticon.name,caticon)
  p=models.SubCategory(catnm=catnm,subcatnm=subcatnm,subcaticonnm=filename)  
  p.save()      
  return render(request,"addsubcategory.html",{"output":"Sub category added successfully....","clist":clist,"sunm":request.session["sunm"]})               

def viewfunds(request):
 pDetails=user_models.Payment.objects.all()
 return render(request,"viewfunds.html",{'pDetails':pDetails,"sunm":request.session["sunm"]})

def cpadmin(request):
 if request.method=="GET":     
  return render(request,"cpadmin.html",{"sunm":request.session["sunm"],"output":""})
 else:
  opass=request.POST.get("opass")
  npass=request.POST.get("npass")
  cnpass=request.POST.get("cnpass")
  sunm=request.session["sunm"]
  userDetails=mydjapp_models.Register.objects.filter(username=sunm,password=opass)
  
  if len(userDetails)>0:
   if npass==cnpass:
    mydjapp_models.Register.objects.filter(username=sunm).update(password=cnpass) 
    msg="Password changed successfully , please login again"
   else:
    msg="New & Confirm new password mis match"      
  else:  
   msg="Invalid old password , please try again"    
  return render(request,"cpadmin.html",{"sunm":sunm,"output":msg})   

def epadmin(request):
 if request.method=="GET":  
  sunm=request.session["sunm"]
  userDetails=mydjapp_models.Register.objects.filter(username=sunm)
 
  m,f="",""
  gender=userDetails[0].gender
  if gender=="male":
   m="checked"
  else:
   f="checked"
  return render(request,"epadmin.html",{"userDetails":userDetails[0],"sunm":request.session["sunm"],"output":"","m":m,"f":f})
 else:
  name=request.POST.get("name")
  username=request.POST.get("username")
  mobile=request.POST.get("mobile")
  address=request.POST.get("address")
  city=request.POST.get("city")
  gender=request.POST.get("gender")    
  mydjapp_models.Register.objects.filter(username=username).update(name=name,mobile=mobile,address=address,city=city,gender=gender)
  return redirect("/myadmin/epadmin/")

def addproduct(request):
 clist=models.Category.objects.all()  
 if request.method=="GET":  
  return render(request,"addproduct.html",{"sunm":request.session["sunm"],"output":"","clist":clist})
 else:
  ptitle=request.POST.get("ptitle")
  pcategory=request.POST.get("pcategory")  
  pscategory=request.POST.get("pscategory")
  pdescription=request.POST.get("pdescription")
  pprice=request.POST.get("pprice")
  
  p=models.Product(ptitle=ptitle,pcategory=pcategory,pscategory=pscategory,pdescription=pdescription,pprice=pprice)
  p.save()
  return render(request,"addproduct.html",{"sunm":request.session["sunm"],"output":"Product added successfully....","clist":clist})             