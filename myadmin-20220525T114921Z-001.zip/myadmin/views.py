from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage

from mydjapp import models as mydjapp_models
from . import models
import mydjapp

# Create your views here.

#middleware to check session for admin routes
def sessioncheckmyadmin_middleware(get_response):
	def middleware(request):
		if request.path=='/myadmin/' or request.path=='/myadmin/addcategory/' or request.path=='/myadmin/addsubcategory/' or request.path=='/myadmin/manageusers/' or request.path=='/myadmin/manageuserstatus/':
			if request.session['sunm']==None or request.session['srole']!="admin":
				response = redirect('/login/')
			else:
				response = get_response(request)
		else:
			response = get_response(request)		
		return response	
	return middleware

def adminhome(request):

 return render(request,"adminhome.html",{"sunm":request.session["sunm"]})

def manageusers(request):
 userDetails=mydjapp_models.Register.objects.filter(role='user')
 return render(request,"manageusers.html",{'userDetails':userDetails,"sunm":request.session["sunm"]})

def manageuserstatus(request):
 regid=request.GET.get("regid")
 s=request.GET.get("s")
 if s=="block":
  mydjapp_models.Register.objects.filter(regid=int(regid)).update(status=0)
 elif s=="verify":
  mydjapp_models.Register.objects.filter(regid=int(regid)).update(status=1)             
 else:
  mydjapp_models.Register.objects.filter(regid=int(regid)).delete()    
 return redirect("/myadmin/manageusers/")

def addcategory(request):
 if request.method=="GET":    
  return render(request,"addcategory.html",{"output":"","sunm":request.session["sunm"]})
 else:
  catnm=request.POST.get("catnm")
  caticon=request.FILES["caticon"]
  fs = FileSystemStorage()
  filename = fs.save(caticon.name,caticon)
  p=models.Category(catnm=catnm,caticonnm=filename)  
  p.save()      
  return render(request,"addcategory.html",{"output":"Category added successfully....","sunm":request.session["sunm"]})

def addsubcategory(request):
 clist=models.Category.objects.all()        
 if request.method=="GET":    
  return render(request,"addsubcategory.html",{"output":"","clist":clist,"sunm":request.session["sunm"]})
 else:
  catnm=request.POST.get("catnm")
  subcatnm=request.POST.get("subcatnm")
  caticon=request.FILES["caticon"]
  fs = FileSystemStorage()
  filename = fs.save(caticon.name,caticon)
  p=models.SubCategory(catnm=catnm,subcatnm=subcatnm,subcaticonnm=filename)  
  p.save()      
  return render(request,"addsubcategory.html",{"output":"Sub category added successfully....","clist":clist,"sunm":request.session["sunm"]})                 